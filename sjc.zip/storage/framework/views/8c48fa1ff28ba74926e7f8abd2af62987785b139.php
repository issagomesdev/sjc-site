<header class="navbar navbar-fixed-top" role="banner">
    <div class="container-responsive">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only"> Menu </span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(route("home")); ?>"> SJC </a>
        </div>
        <nav id="bs-example-navbar-collapse-1" class="collapse navbar-collapse">
        <ul id="menu-header" class="nav navbar-nav navbar-right">
        <li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="Home" href="<?php echo e(route("home")); ?>"> Home </a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="Sobre nós" href="<?php echo e(route("sobre-nos")); ?>"> Sobre nós </a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="SJC Educacional" href="<?php echo e(route("sjc-educacional")); ?>"> SJC Educacional </a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="Contato" href="<?php echo e(route("contato")); ?>"> Contato </a></li>
        <li class="menu-item btn btn-alma"><a href="<?php echo e(route("info")); ?>"> Mais Informações </a> </li>
        </ul>
      </nav>
</div>
</header>
<?php /**PATH C:\laragon\www\sjc-site\resources\views/layouts/menu.blade.php ENDPATH**/ ?>