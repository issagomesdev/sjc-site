<footer class="site-footer" role="contentinfo">
  <div class="container">
  <div class="footer-content">
  <div class="row">
  <div class="col-sm-7">
  <div class="menu-footer-container">

   <ul id="menu-footer" class="footer-nav">

  <li id="menu-item-1214" class="menu-item menu-item-type-customS"> <h5>Sobre nós</h5> <ul class="sub-menu">
    <li class="menu-item menu-item-type-custom"> <a href="<?php echo e(route("sobre-nos")); ?>#quem-somos"> Quem Somos </a> </li>
    <li class="menu-item menu-item-type-custom"> <a href="<?php echo e(route("sobre-nos")); ?>#nossa-missao"> Nossa Missão </a> </li>
    <li class="menu-item menu-item-type-custom"> <a href="<?php echo e(route("sobre-nos")); ?>#valores"> Valores </a> </li>
    <li class="menu-item menu-item-type-custom"> <a href="<?php echo e(route("sobre-nos")); ?>#visao"> Visão </a> </li>
  </ul> </li>

  <li id="menu-item-1215" class="menu-item menu-item-type-customS"> <h5> SJC Educacional </h5> <ul class="sub-menu">
    <li class="menu-item menu-item-type-custom"> <a href="<?php echo e(route("sjc-educacional")); ?>"> Conheça nosso sistema <br> de gestão escolar </a> </li>
  </ul> </li>

  <li id="menu-item-1216" class="menu-item menu-item-type-customS"> <h5> Contato </h5> <ul class="sub-menu">

    <li class="menu-item menu-item-type-custom"> <a href="https://www.google.com/maps/dir//sjc+sistemas/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x7ab191eb9341737:0x48ad4d64ce13fe65?sa=X&ved=2ahUKEwiYgsTElLD2AhWTrosKHcBwDnkQ9Rd6BAgjEAQ">
        Rua Doutor Luiz Ribeiro Bastos, 51 - CXPST - 406 - Poço da Panela, Recife - PE, 52060-490 <br>
    </a> </li>
    <li class="menu-item menu-item-type-custom"> <a href="mailto:contato@sjcsistemas.com.br"> contato@sjcsistemas.com.br </a> </li>
    <li class="menu-item menu-item-type-custom"> <a href="tel:55-81-98189-7442">+55(81)98189-7442</a> </li>
  </ul> </li>



</ul></div>                    </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\sjc-site\resources\views/layouts/footer.blade.php ENDPATH**/ ?>